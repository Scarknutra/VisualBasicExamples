﻿Imports System
Imports System.IO
Module Module1
    'global variable declaration
    Dim response As Integer
    Dim readValue As String
    Dim Name1 As String
    Dim newValue As String
    Dim newKeyName As String
    Dim thing As Object


    Sub Main()
        'Main menu function
        Console.WriteLine("What would you like to do?")
        Console.WriteLine("Type 1 to read a key or view all keys")
        Console.WriteLine("Type 2 to write a key")
        Console.WriteLine("Type 3 to create a key")
        Console.WriteLine("Type 4 to delete a key")
        Console.WriteLine("Type 5 to leave the program")
        response = Console.ReadLine

        Select Case response
            Case 1
                ReadFunction()
                Main()
            Case 2
                WriteFunction()
                Main()
            Case 3
                CreateFunction()
                Main()
            Case 4
                DeleteFunction()
                Main()
            Case 5
                End
            Case Else
                Console.WriteLine("Oh no! Please type a whole number between 1 and 5")
                Main()
        End Select
    End Sub
    Function ReadFunction() As Integer
        'read function to view keys
        Console.WriteLine("Which key would you like to read? Type 'all' to see all or 'recursive' to see the value of each key")
        Name1 = Console.ReadLine
        If Name1 = "all" Then
            For Each item In My.Computer.Registry.CurrentUser.GetSubKeyNames
                Console.WriteLine(item)
            Next
        ElseIf Name1 = "recursive" Then
            RecursiveRead()
        Else
            readValue = My.Computer.Registry.GetValue("HKEY_CURRENT_USER\" & Name1, Name1, Nothing)
            Console.WriteLine("The value is " & readValue)
        End If
        Return "1"
    End Function

    Function WriteFunction() As Integer
        'write function
        Console.WriteLine("Which key would you like to edit?")
        Name1 = Console.ReadLine
        readValue = My.Computer.Registry.GetValue("HKEY_CURRENT_USER\" & Name1, Name1, Nothing)
        Console.WriteLine("The value is " & readValue)
        Console.WriteLine("What is the new value?")
        newValue = Console.ReadLine
        My.Computer.Registry.SetValue("HKEY_CURRENT_USER\" & Name1, Name1, newValue)
        Return "1"
    End Function

    Function CreateFunction() As Integer
        'create function
        Console.WriteLine("What will the new key be called?")
        newKeyName = Console.ReadLine
        My.Computer.Registry.CurrentUser.CreateSubKey(newKeyName)
        Console.WriteLine("What is the value of this key?")
        newValue = Console.ReadLine
        My.Computer.Registry.SetValue("HKEY_CURRENT_USER\" & newKeyName, newKeyName, newValue)
        Return "1"
    End Function

    Function DeleteFunction() As Integer
        'delete function
        Console.WriteLine("Which key would you like to delete?")
        Name1 = Console.ReadLine
        readValue = My.Computer.Registry.GetValue("HKEY_CURRENT_USER\" & Name1, Name1, Nothing)
        Console.WriteLine("The value is " & readValue)
        My.Computer.Registry.CurrentUser.DeleteSubKey(Name1)
        Console.WriteLine("The key is deleted")
        Return "1"
    End Function
    Function RecursiveRead() As Integer
        For Each thing In My.Computer.Registry.CurrentUser.GetSubKeyNames
            Console.WriteLine(thing)
            readValue = My.Computer.Registry.GetValue("HKEY_CURRENT_USER\" & thing, thing, Nothing)
            Console.WriteLine("The value is " & readValue)
        Next
        Return "1"
    End Function
End Module
